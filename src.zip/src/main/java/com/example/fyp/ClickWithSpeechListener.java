package com.example.fyp;

import android.view.View;

public class ClickWithSpeechListener implements View.OnClickListener {
    private boolean isFirstClick = true;
    private final String speechText;
    private final View.OnClickListener action;
    private final cart_pageActivity activity; // Reference to the activity

    public ClickWithSpeechListener(cart_pageActivity activity, String speechText, View.OnClickListener action) {
        this.activity = activity;
        this.speechText = speechText;
        this.action = action;
    }

    @Override
    public void onClick(View v) {
        if (isFirstClick) {
            // Speak the provided text on the first click
            activity.speakText(speechText);
            isFirstClick = false; // Mark as spoken
        } else {
            // Perform the main action on subsequent clicks
            action.onClick(v);
        }
    }
}
