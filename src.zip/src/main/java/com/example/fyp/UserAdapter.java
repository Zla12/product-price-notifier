package com.example.fyp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private List<User> userList;

    // Constructor for the adapter to initialize the user list
    public UserAdapter(List<User> userList) {
        this.userList = userList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each row in the table (table_row_item.xml)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.table_row_item, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        // Bind each user's data to the respective TextViews and CheckBox
        User user = userList.get(position);

        // Corrected field references to match the updated User class
        holder.checkbox.setChecked(user.isSelected());
        holder.tvNo.setText(String.valueOf(user.getNo()));
        holder.tvUsername.setText(user.getUsername());
        holder.tvPhone.setText(user.getPhoneNumber());
        holder.tvEmail.setText(user.getEmail());

        // Checkbox listener to update the selection status
        holder.checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> user.setSelected(isChecked));
    }

    @Override
    public int getItemCount() {
        return userList.size(); // Return the total number of items
    }

    // ViewHolder class for each row in RecyclerView
    public static class UserViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkbox;
        TextView tvNo, tvUsername, tvPhone, tvEmail;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkbox);
            tvNo = itemView.findViewById(R.id.tv_no);
            tvUsername = itemView.findViewById(R.id.tv_username);
            tvPhone = itemView.findViewById(R.id.tv_phone);
            tvEmail = itemView.findViewById(R.id.tv_email);
        }
    }
}
