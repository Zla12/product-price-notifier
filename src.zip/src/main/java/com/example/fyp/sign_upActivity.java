package com.example.fyp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class sign_upActivity extends AppCompatActivity {

    EditText signupUsername, signupPhoneNumber, signupEmail, signupPassword;
    TextView SignIn;
    Button signUpButton;
    FirebaseDatabase database;
    DatabaseReference reference;
    FirebaseAuth mAuth;
    private TextToSpeech textToSpeech;
    private boolean isFirstClick = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        signupUsername = findViewById(R.id.Username);
        signupPhoneNumber = findViewById(R.id.PhoneNumber);
        signupEmail = findViewById(R.id.EmailAddress);
        signupPassword = findViewById(R.id.Password);
        SignIn = findViewById(R.id.SignIn);
        signUpButton = findViewById(R.id.sign_up_button2);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = textToSpeech.setLanguage(Locale.ENGLISH);
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(sign_upActivity.this, "Language not supported for TTS", Toast.LENGTH_SHORT).show();
                    } else {
                        // Speak the message when TTS is ready
                        speakMessage("Sign up page, please fill in the blank");
                    }
                } else {
                    Toast.makeText(sign_upActivity.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set onClickListeners for each EditText field
        signupUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakMessage("Enter username");
            }
        });

        signupPhoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakMessage("Enter phone number");
            }
        });

        signupEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakMessage("Enter email address");
            }
        });

        signupPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakMessage("Enter new password");
            }
        });


        // Set the onClickListener for the sign-up button
        signUpButton.setOnClickListener(view -> {
            if (isFirstClick) {
                // On the first click, speak "sign up button"
                speakMessage("Sign up button");
                isFirstClick = false; // Change the flag so the next click will perform the actual function
            } else {
                // On the second click, perform the actual sign-up functionality
                String username = signupUsername.getText().toString().trim();
                String phoneNumber = signupPhoneNumber.getText().toString().trim();
                String email = signupEmail.getText().toString().trim();
                String password = signupPassword.getText().toString().trim();

                if (username.isEmpty() || phoneNumber.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(sign_upActivity.this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
                } else {
                    createAccount(username, phoneNumber, email, password);
                }
            }
        });

        SignIn.setOnClickListener(view -> {
            Intent intent = new Intent(sign_upActivity.this, sign_inActivity.class);
            startActivity(intent);
        });

    }

    private void createAccount(final String username, final String phoneNumber, final String email, final String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        reference = database.getReference("users");
                        HelperClass helperClass = new HelperClass(username, phoneNumber, email, password);
                        reference.child(FirebaseAuth.getInstance().getUid()).setValue(helperClass);

                        Toast.makeText(sign_upActivity.this, "Account successfully created", Toast.LENGTH_SHORT).show();
                        speakMessage("Account successfully created");
                        clearInputFields();

                        // Add a delay before navigating back to sign_inActivity
                        new android.os.Handler().postDelayed(() -> {
                            Intent intent = new Intent(sign_upActivity.this, sign_inActivity.class);
                            startActivity(intent);
                            finish(); // Close sign-up activity
                        }, 2000); // 2-second delay
                    } else {
                        if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                            Toast.makeText(sign_upActivity.this, "Email is already in use.", Toast.LENGTH_SHORT).show();
                            speakMessage("email is already in use");
                        } else {
                            Toast.makeText(sign_upActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void clearInputFields() {
        signupUsername.setText("");
        signupPhoneNumber.setText("");
        signupEmail.setText("");
        signupPassword.setText("");
    }

    // Helper method to speak a message
    private void speakMessage(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }


    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown(); // Release TTS resources
        }
        super.onDestroy();
    }
}