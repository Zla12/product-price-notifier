package com.example.fyp;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class user_IntActivity extends AppCompatActivity {

    private TextView DateAndDay, welcomeTextView;;
    Button ScanBarcode;
    private DatabaseReference database;
    private ImageView logoutButton, voiceRecognitionButton;
    private TextToSpeech textToSpeech;
    private boolean isFirstLogoutClick = true;
    private boolean isFirstCartClick = true;

    private static final int VOICE_RECOGNITION_REQUEST_CODE = 123;

    @Override //SET DATE & TIME
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_int);

        // Check if the activity was launched with the "skipSpeech" extra
        boolean skipSpeech = getIntent().getBooleanExtra("skipSpeech", false);

        logoutButton = findViewById(R.id.profileIcon);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFirstLogoutClick) {
                    speakMessage("Logout button");
                    isFirstLogoutClick = false;
                } else {
                    logoutUser();
                }
            }

            private void logoutUser() {
                // Clear user session data from SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clears all data
                editor.apply(); // Apply changes

                // Redirect user to the login screen
                Intent intent = new Intent(user_IntActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
                startActivity(intent);
                finish(); // Close the current activity
            }
        });

        // Check if the user is authenticated
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Intent intent = new Intent(user_IntActivity.this, sign_inActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // Initialize Views
        DateAndDay = findViewById(R.id.DateAndDay);
        welcomeTextView = findViewById(R.id.WelcomeMessage);
        ScanBarcode = findViewById(R.id.ScanBarcode);
        ImageView cartIcon = findViewById(R.id.cartIcon);
        ImageView profileIcon = findViewById(R.id.profileIcon);
        voiceRecognitionButton = findViewById(R.id.voiceRecognition);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.ENGLISH);

                if (!skipSpeech) {
                    // Only speak the welcome message and instructions if "skipSpeech" is false
                    speakWelcomeAndInstructions();
                }
            } else {
                Toast.makeText(this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Set Current Date
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy, EEEE", Locale.getDefault());
        String currentDateAndDay = sdf.format(new Date());
        DateAndDay.setText(currentDateAndDay);

        // Retrieve Username from Intent
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            welcomeTextView.setText("Welcome, " + username);
        } else {
            welcomeTextView.setText("Welcome, User");
        }

        // Barcode Scanning Button
        ScanBarcode.setOnClickListener(view -> {
            IntentIntegrator intentIntegrator = new IntentIntegrator(user_IntActivity.this);
            intentIntegrator.setOrientationLocked(true);
            intentIntegrator.setPrompt("Scan a Barcode (Press Volume Up Button to Open FlashLight)");
            intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
            intentIntegrator.initiateScan();
        });

        // Cart Button
        cartIcon.setOnClickListener(view -> {
                    if (isFirstCartClick) {
                        // Speak "shopping cart button" on the first click
                        speakMessage("Shopping cart button");
                        isFirstCartClick = false; // Update the flag so the next click will navigate
                    } else {
                        Intent myIntent = new Intent(user_IntActivity.this, shoppingCart_pageActivity.class);
                        startActivity(myIntent);
                    }
                });

        // Voice Recognition Button
        voiceRecognitionButton.setOnClickListener(view -> {
            // Speak instructions first, then start voice recognition
            speakMessage("To scan barcode, speak 'scan barcode'. To view shopping cart, speak 'open shopping cart'. To log out, speak 'logout'.");
            voiceRecognitionButton.postDelayed(this::startVoiceRecognition, 2000); // Delay to allow speech to complete
        });

        // Initialize Firebase Reference for Barcodes
        database = FirebaseDatabase.getInstance().getReference("barcodes");
        // Set up Voice Recognition Button
        voiceRecognitionButton.setOnClickListener(view -> startVoiceRecognition());
        // Set up Voice Recognition Button
        voiceRecognitionButton.setOnClickListener(view -> startVoiceRecognition());
    }

    private void speakWelcomeAndInstructions() {
        // Welcome Message
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            speakMessage("Welcome " + username);
        } else {
            speakMessage("Welcome User");
        }

        // Instructions for Buttons
        voiceRecognitionButton.postDelayed(() ->
                speakMessage("The orange button is to scan barcode, and the blue button is to use voice instruction."), 3000);
    }

    private void startVoiceRecognition() {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your command");
            try {
                startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Voice recognition not supported on your device", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (result != null && !result.isEmpty()) {
                    String command = result.get(0).toLowerCase();
                    processVoiceCommand(command);
                }
            } else if (requestCode == IntentIntegrator.REQUEST_CODE) {
                // Handle barcode scanning results
                IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
                if (intentResult != null) {
                    if (intentResult.getContents() == null) {
                        Toast.makeText(this, "Scan Cancelled", Toast.LENGTH_SHORT).show();
                    } else {
                        String scannedBarcode = intentResult.getContents();
                        validateBarcodeAndNavigate(scannedBarcode);
                    }
                }
            }
        }

    // Process the voice command
    private void processVoiceCommand(String command) {
        if (command.contains("scan barcode")) {
            // Simulate clicking the Scan Barcode button
            ScanBarcode.performClick();
        } else if (command.contains("open shopping cart")) {
            // Simulate clicking the Cart button
            Intent myIntent = new Intent(user_IntActivity.this, shoppingCart_pageActivity.class);
            startActivity(myIntent);
        } else if (command.contains("logout")) {
            // Log out the user
            logoutUser();
        } else {
            Toast.makeText(this, "Command not recognized: " + command, Toast.LENGTH_SHORT).show();
        }
    }

    private void speakMessage(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void logoutUser() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Clears all data
        editor.apply(); // Apply changes

        // Redirect user to the login screen
        Intent intent = new Intent(user_IntActivity.this, sign_inActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
        startActivity(intent);
        finish(); // Close the current activity
    }

    private void validateBarcodeAndNavigate(String scannedBarcode) {
        // Check if the barcode exists in Firebase before proceeding
        database.child(scannedBarcode).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Barcode exists, navigate to cart_pageActivity
                    Intent intent = new Intent(user_IntActivity.this, cart_pageActivity.class);
                    intent.putExtra("BARCODE", scannedBarcode);
                    startActivity(intent);
                } else {
                    // Barcode not found in database
                    Toast.makeText(user_IntActivity.this, "Barcode not found in database.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(user_IntActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("Firebase", "Error: " + error.getMessage());
            }
        });
    }
    }

