package com.example.fyp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Singleton class to manage cart items globally across the app.
 */
public class CartManager {
    private static CartManager instance; // Singleton instance
    private final Map<String, CartItem> cartItems; // Stores cart items using a map

    // Private constructor to enforce Singleton pattern
    private CartManager() {
        cartItems = new HashMap<>();
    }

    /**
     * Get the singleton instance of CartManager.
     */
    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    /**
     * Add an item to the cart.
     * If the item already exists, increment its quantity.
     *
     * @param id       Unique identifier of the product
     * @param name     Name of the product
     * @param price    Price of the product
     * @param quantity Quantity to add
     * @param imageUrl URL of the product image
     */
    public void addItem(String id, String name, double price, int quantity, String imageUrl) {
        if (cartItems.containsKey(id)) {
            CartItem existingItem = cartItems.get(id);
            existingItem.incrementQuantity(quantity);
        } else {
            CartItem newItem = new CartItem(id, name, price, quantity, imageUrl);
            cartItems.put(id, newItem);
        }
    }

    /**
     * Get all cart items.
     *
     * @return A map of all cart items
     */
    public Map<String, CartItem> getCartItems() {
        return new HashMap<>(cartItems); // Return a copy to prevent direct modification
    }

    /**
     * Update the quantity of an item in the cart.
     *
     * @param id       Unique identifier of the product
     * @param quantity New quantity to set
     */
    public void updateItemQuantity(String id, int quantity) {
        if (cartItems.containsKey(id)) {
            CartItem item = cartItems.get(id);
            item.setQuantity(quantity);
        }
    }

    /**
     * Update the image URL of an item in the cart.
     *
     * @param id       Unique identifier of the product
     * @param imageUrl New image URL to set
     */
    public void updateItemImageUrl(String id, String imageUrl) {
        if (cartItems.containsKey(id)) {
            CartItem item = cartItems.get(id);
            item.setImageUrl(imageUrl);
        }
    }

    /**
     * Calculate the total price of all items in the cart.
     *
     * @return The total price
     */
    public double calculateTotalPrice() {
        double totalPrice = 0.0;
        for (CartItem item : cartItems.values()) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        return totalPrice;
    }

    /**
     * Remove an item from the cart.
     *
     * @param id Unique identifier of the product to remove
     */
    public void removeItem(String id) {
        cartItems.remove(id);
    }

    /**
     * Clear all items in the cart.
     */
    public void clearCart() {
        cartItems.clear();
    }

    /**
     * Check if the cart is empty.
     *
     * @return True if the cart is empty, false otherwise
     */
    public boolean isCartEmpty() {
        return cartItems.isEmpty();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (CartItem item : cartItems.values()) {
            sb.append(item.toString()).append("\n");
        }
        return sb.toString();
    }
    public List<CartItem> getCartItemsAsList() {
        return new ArrayList<>(cartItems.values());
    }
}