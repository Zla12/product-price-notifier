package com.example.fyp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class adminShoppingCartSummary extends AppCompatActivity {

    private TableLayout tableLayout;
    private TextView totalPriceTextView;
    private DatabaseReference completedCartsRef;
    private Button okayButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_shopping_cart_summary);

        tableLayout = findViewById(R.id.tableLayout);
        totalPriceTextView = findViewById(R.id.total_price_text_view);

        String checkoutId = getIntent().getStringExtra("COMPLETED_CART_ID");
        completedCartsRef = FirebaseDatabase.getInstance().getReference("CompletedCarts").child(checkoutId);

        loadCartDetails();
        loadTotalPrice(); // Fetch the total price and display it
    }



    private void loadCartDetails() {
        completedCartsRef.child("items").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tableLayout.removeViews(1, Math.max(0, tableLayout.getChildCount() - 1));
                int no = 1;

                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    String name = itemSnapshot.child("name").getValue(String.class);
                    Double price = Double.valueOf(itemSnapshot.child("price").getValue(String.class));
                    Long quantity = itemSnapshot.child("quantity").getValue(Long.class);
                    double totalPrice = price * quantity;

                    TableRow row = new TableRow(adminShoppingCartSummary.this);
                    row.addView(createTextView(String.valueOf(no++)));
                    row.addView(createTextView(name));
                    row.addView(createTextView(String.format("%.2f", price)));
                    row.addView(createTextView(String.valueOf(quantity)));
                    row.addView(createTextView(String.format("%.2f", totalPrice)));

                    tableLayout.addView(row);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void loadTotalPrice() {
        // Fetch the total price from Firebase
        completedCartsRef.child("totalPrice").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Get the total price as a String
                String totalPriceString = snapshot.getValue(String.class);

                // Update the total price TextView
                if (totalPriceString != null) {
                    totalPriceTextView.setText(String.format("Total Price: RM %s", totalPriceString));
                } else {
                    totalPriceTextView.setText("Total Price: RM 0.00");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                totalPriceTextView.setText("Failed to load total price");
            }
        });

        okayButton = findViewById(R.id.btn_Okay);
        okayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(adminShoppingCartSummary.this, adminPaymentHistory.class);
                startActivity(myIntent);
                finish();
            }
        });
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(android.view.Gravity.CENTER);
        return textView;
    }
}