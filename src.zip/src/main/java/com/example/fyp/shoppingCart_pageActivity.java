package com.example.fyp;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.speech.tts.TextToSpeech;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class shoppingCart_pageActivity extends AppCompatActivity {

    private TableLayout tableLayout;
    private Button checkoutButton;
    private boolean isSaving = false;
    private List<CartItem> cartItems;
    private TextToSpeech textToSpeech;
    private boolean isFirstCheckoutClick = true; // Flag for tracking the first click


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart_page);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                // Set language to English
                int result = textToSpeech.setLanguage(Locale.ENGLISH);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(this, "TTS Language not supported!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "TTS Initialization failed!", Toast.LENGTH_SHORT).show();
            }
        });

        checkoutButton = findViewById(R.id.checkOutbutton);
        tableLayout = findViewById(R.id.tableLayout);

        // Set up click listener for checkoutButton
        checkoutButton.setOnClickListener(view -> {
            if (isFirstCheckoutClick) {
                // Speak "Checkout button" on the first click
                speakText("Checkout button");
                isFirstCheckoutClick = false; // Update the flag
            } else {
                // Second click: Navigate to paymentBarcode_pageActivity
                double totalPrice = CartManager.getInstance().calculateTotalPrice();

                // Pass total price to the payment activity
                Intent intent = new Intent(this, paymentBarcode_pageActivity.class);
                intent.putExtra("TOTAL_PRICE", totalPrice);
                startActivity(intent);
            }
        });
        tableLayout = findViewById(R.id.tableLayout);

        tableLayout = findViewById(R.id.tableLayout);

        // Retrieve cart items from CartManager
        cartItems = new ArrayList<>(CartManager.getInstance().getCartItems().values());

        // Populate the cart table
        updateCartTable();
    }

    private void saveCompletedCart(double totalPrice, Runnable onComplete) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please log in to complete checkout.", Toast.LENGTH_SHORT).show();
            onComplete.run();
            return;
        }

        String userKey = auth.getCurrentUser().getUid();
        String username = auth.getCurrentUser().getEmail(); // Using email as username
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference();

        // Generate a unique checkout ID
        String checkoutId = databaseRef.child("CompletedCarts").push().getKey();
        if (checkoutId == null) {
            Toast.makeText(this, "Error generating checkout ID. Try again.", Toast.LENGTH_SHORT).show();
            onComplete.run();
            return;
        }

        String dateFormatted = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Prepare CompletedCarts data
        Map<String, Object> completedCartData = new HashMap<>();
        completedCartData.put("userKey", userKey);
        completedCartData.put("username", username);
        completedCartData.put("totalPrice", String.format(Locale.getDefault(), "%.2f", totalPrice));
        completedCartData.put("date", dateFormatted);

        Map<String, Object> items = new HashMap<>();
        for (CartItem item : CartManager.getInstance().getCartItems().values()) {
            Map<String, Object> itemData = new HashMap<>();
            itemData.put("name", item.getName());
            itemData.put("quantity", item.getQuantity());
            itemData.put("price", String.format(Locale.getDefault(), "%.2f", item.getPrice()));
            itemData.put("totalPrice", String.format(Locale.getDefault(), "%.2f", item.getPrice() * item.getQuantity()));
            items.put(item.getId(), itemData);
        }
        completedCartData.put("items", items);

        // Save to CompletedCarts
        databaseRef.child("CompletedCarts").child(checkoutId).setValue(completedCartData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Prepare PaymentHistory data
                Map<String, Object> paymentHistoryData = new HashMap<>();
                paymentHistoryData.put("userKey", userKey);
                paymentHistoryData.put("username", username);
                paymentHistoryData.put("totalPrice", String.format(Locale.getDefault(), "%.2f", totalPrice));
                paymentHistoryData.put("date", dateFormatted);

                // Save to PaymentHistory
                databaseRef.child("PaymentHistory").child(checkoutId).setValue(paymentHistoryData).addOnCompleteListener(historyTask -> {
                    if (historyTask.isSuccessful()) {
                        Toast.makeText(this, "Checkout completed successfully!", Toast.LENGTH_SHORT).show();
                        CartManager.getInstance().clearCart(); // Clear the cart
                    } else {
                        Toast.makeText(this, "Failed to save payment history.", Toast.LENGTH_SHORT).show();
                    }
                    onComplete.run();
                });
            } else {
                Toast.makeText(this, "Failed to save completed cart.", Toast.LENGTH_SHORT).show();
                onComplete.run();
            }
        });
    }

        private void addItemToCartTable(CartItem item, int position) {
        // Inflate the table row layout
        View tableRow = getLayoutInflater().inflate(R.layout.table_row_item, null);

        // Initialize views in the inflated layout
        TextView itemNumber = tableRow.findViewById(R.id.item_number);
        ImageView itemImage = tableRow.findViewById(R.id.item_image);
        TextView itemName = tableRow.findViewById(R.id.item_name);
        TextView itemQuantity = tableRow.findViewById(R.id.item_quantity);
        Button btnDecrease = tableRow.findViewById(R.id.btn_decrease);
        Button btnIncrease = tableRow.findViewById(R.id.btn_increase);
        ImageView itemDelete = tableRow.findViewById(R.id.item_delete);

        // Set values
        itemNumber.setText(String.valueOf(position + 1));
        itemName.setText(item.getName());
        itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Load image using Glide with placeholder and error handling
        Glide.with(this)
                .load(item.getImageUrl())
                .placeholder(new ColorDrawable(Color.GRAY))
                .error(new ColorDrawable(Color.RED))
                .into(itemImage);

            // Set up flag variables for speech tracking
            final boolean[] isFirstIncreaseClick = {true}; // Flag for the first click on increase button
            final boolean[] isFirstDecreaseClick = {true}; // Flag for the first click on decrease button
            final boolean[] isFirstDeleteClick = {true}; // Flag for the first click on delete button



            // Set up the quantity increase button
            btnIncrease.setOnClickListener(view -> {
                if (isFirstIncreaseClick[0]) {
                    // Speak "Increase item button" on the first click
                    speakText("Increase item button");
                    isFirstIncreaseClick[0] = false; // Update the flag
                } else {
                    // On subsequent clicks, increase the quantity, update the database, and speak the current quantity
                    item.incrementQuantity(1);
                    updateQuantityInFirebase(item.getId(), -1); // Deduct from Firebase
                    updateCartTable(); // Refresh the cart table

                    // Speak the current quantity after updating
                    speakText("Current quantity is " + item.getQuantity());
                }
            });

            // Set up the quantity decrease button
            btnDecrease.setOnClickListener(view -> {
                if (isFirstDecreaseClick[0]) {
                    // Speak "Decrease item button" on the first click
                    speakText("Decrease item button");
                    isFirstDecreaseClick[0] = false; // Update the flag
                } else {
                    // On subsequent clicks, decrease the quantity, update the database, and speak the current quantity
                    if (item.getQuantity() > 1) {
                        item.decrementQuantity(1);
                        updateQuantityInFirebase(item.getId(), 1); // Add back to Firebase
                        updateCartTable(); // Refresh the cart table

                        // Speak the current quantity after updating
                        speakText("Current quantity is " + item.getQuantity());
                    }
                }
            });

            // Set up the delete button
            itemDelete.setOnClickListener(v -> {
                if (isFirstDeleteClick[0]) {
                    // Speak "Delete item button" on the first click
                    speakText("Delete item button");
                    isFirstDeleteClick[0] = false; // Update the flag
                } else {
                    // On subsequent clicks, perform the delete functionality
                    restoreQuantityInFirebase(item.getId(), item.getQuantity()); // Restore quantity in Firebase
                    CartManager.getInstance().removeItem(item.getId()); // Remove the item from the cart
                    updateCartTable(); // Refresh the cart table
                }
            });

        // Add the row to the table layout
        tableLayout.addView(tableRow);
    }

    private void speakText(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            Toast.makeText(this, "Text-to-Speech not initialized", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private void restoreQuantityInFirebase(String productId, int quantityToRestore) {
        DatabaseReference productRef = FirebaseDatabase.getInstance().getReference("barcodes").child(productId);

        productRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Product product = dataSnapshot.getValue(Product.class);

                    if (product != null) {
                        int currentQuantity = Integer.parseInt(product.getQuantity());
                        int restoredQuantity = currentQuantity + quantityToRestore; // Add back the cart quantity

                        // Update the restored quantity in Firebase
                        productRef.child("quantity").setValue(String.valueOf(restoredQuantity))
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(shoppingCart_pageActivity.this, "Quantity restored successfully!", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(shoppingCart_pageActivity.this, "Failed to restore quantity", Toast.LENGTH_SHORT).show();
                                });
                    }
                } else {
                    Toast.makeText(shoppingCart_pageActivity.this, "Product not found in database!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(shoppingCart_pageActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateQuantityInFirebase(String productId, int change) {
        DatabaseReference productRef = FirebaseDatabase.getInstance().getReference("barcodes").child(productId);

        productRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Product product = dataSnapshot.getValue(Product.class);

                    if (product != null) {
                        int currentQuantity = Integer.parseInt(product.getQuantity());
                        int newQuantity = currentQuantity + change; // Add or subtract the change

                        if (newQuantity < 0) {
                            Toast.makeText(shoppingCart_pageActivity.this, "Insufficient stock!", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Update the quantity in Firebase
                        productRef.child("quantity").setValue(String.valueOf(newQuantity))
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(shoppingCart_pageActivity.this, "Quantity updated successfully!", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(shoppingCart_pageActivity.this, "Failed to update quantity", Toast.LENGTH_SHORT).show();
                                });
                    }
                } else {
                    Toast.makeText(shoppingCart_pageActivity.this, "Product not found!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(shoppingCart_pageActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void updateCartTable() {
        // Clear all rows except the header
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1);

        cartItems = new ArrayList<>(CartManager.getInstance().getCartItems().values());
        if (cartItems.isEmpty()) {
            TextView emptyMessage = new TextView(this);
            emptyMessage.setText("Your cart is empty.");
            emptyMessage.setPadding(16, 16, 16, 16);
            emptyMessage.setTextColor(Color.BLACK);
            emptyMessage.setTextSize(18);
            tableLayout.addView(emptyMessage);
        } else {
            for (int i = 0; i < cartItems.size(); i++) {
                addItemToCartTable(cartItems.get(i), i);
            }
        }

        // Update total price
        double totalPrice = CartManager.getInstance().calculateTotalPrice();
        TextView totalPriceTextView = findViewById(R.id.total_price_text_view);
        String formattedPrice = String.format("RM %.2f", totalPrice);  // Format price as "RM 15.00"
        totalPriceTextView.setText(formattedPrice);  // Display in UI
    }
}

