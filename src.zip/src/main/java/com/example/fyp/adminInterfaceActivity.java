package com.example.fyp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class adminInterfaceActivity extends AppCompatActivity {
    private TextView DateAndDay, welcomeTextView;
    private Button ListOfUsersButton, ListOfProductsButton, PaymentHistoryButton;
    private ImageView logoutButton;


    @Override //SET DATE & TIME
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_interface);

        logoutButton = findViewById(R.id.profileIcon);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutUser();
            }

            private void logoutUser() {
                // Clear user session data from SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clears all data
                editor.apply(); // Apply changes

                // Redirect user to the login screen
                Intent intent = new Intent(adminInterfaceActivity.this, sign_inActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
                startActivity(intent);
                finish(); // Close the current activity
            }
        });

        DateAndDay = findViewById(R.id.dateTextView);
        welcomeTextView = findViewById(R.id.welcomeTextView);

            Calendar calendar = Calendar.getInstance();
            // Set the current date
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy, EEEE", Locale.getDefault());
            String currentDateAndDay = sdf.format(new Date());
            DateAndDay.setText(currentDateAndDay);

        // Retrieve Username from Intent
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            welcomeTextView.setText("Welcome, " + username);
        } else {
            welcomeTextView.setText("Welcome, Admin");
        }

            ListOfUsersButton = findViewById(R.id.listOfUsersButton);

            ListOfUsersButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent myIntent = new Intent(adminInterfaceActivity.this, adminListOfUsersActivity.class);
                    startActivity(myIntent);
                }
            });

            ListOfProductsButton = findViewById(R.id.listOfProductButton);

            ListOfProductsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent myIntent = new Intent(adminInterfaceActivity.this, adminListOfProducts.class);
                    startActivity(myIntent);
                }
            });

            PaymentHistoryButton = findViewById(R.id.paymentHistoryButton);

            PaymentHistoryButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent myIntent = new Intent(adminInterfaceActivity.this, adminPaymentHistory.class);
                    startActivity(myIntent);
                }
            });



        };

    }
