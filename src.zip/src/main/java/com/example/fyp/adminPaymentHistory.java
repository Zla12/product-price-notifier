package com.example.fyp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class adminPaymentHistory extends AppCompatActivity {

    private TableLayout tableLayout;
    private DatabaseReference paymentHistoryRef;
    private String selectedKey = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_payment_history);

        tableLayout = findViewById(R.id.tableLayout);
        paymentHistoryRef = FirebaseDatabase.getInstance().getReference("PaymentHistory");

        loadPaymentHistory();

        findViewById(R.id.btn_check).setOnClickListener(v -> {
            if (selectedKey != null) {
                Intent intent = new Intent(adminPaymentHistory.this, adminShoppingCartSummary.class);
                intent.putExtra("COMPLETED_CART_ID", selectedKey);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please select a user to check their shopping cart.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadPaymentHistory() {
        paymentHistoryRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                tableLayout.removeViews(1, tableLayout.getChildCount() - 1);

                int index = 1;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String key = snapshot.getKey();
                    String username = snapshot.child("username").getValue(String.class);
                    String totalPrice = snapshot.child("totalPrice").getValue(String.class);
                    String date = snapshot.child("date").getValue(String.class);

                    // Only add rows with email addresses
                    if (username != null && username.contains("@")) {
                        addTableRow(key, String.valueOf(index), username, totalPrice, date);
                        index++;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(adminPaymentHistory.this, "Failed to load payment history.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addTableRow(String key, String number, String username, String totalPrice, String date) {
        TableRow tableRow = new TableRow(this);
        tableRow.setTag(key);

        CheckBox checkBox = new CheckBox(this);
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedKey = key;
                uncheckOtherCheckboxes(tableRow);
            } else if (selectedKey != null && selectedKey.equals(key)) {
                selectedKey = null;
            }
        });

        tableRow.addView(checkBox);
        tableRow.addView(createTextView(number, 50));
        tableRow.addView(createTextView(username, 100));
        tableRow.addView(createTextView(totalPrice, 100));
        tableRow.addView(createTextView(date, 150));
        tableLayout.addView(tableRow);
    }

    private TextView createTextView(String text, int widthDp) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(8, 8, 8, 8);

        int widthPx = (int) (widthDp * getResources().getDisplayMetrics().density);
        textView.setWidth(widthPx);

        textView.setBackgroundResource(R.drawable.border);
        return textView;
    }

    private void uncheckOtherCheckboxes(TableRow selectedRow) {
        for (int i = 1; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            if (row != selectedRow) {
                CheckBox checkBox = (CheckBox) row.getChildAt(0);
                checkBox.setChecked(false);
            }
        }
    }
}