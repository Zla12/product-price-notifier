package com.example.fyp;

public class PaymentHistory {
    public String username;
    public String totalPrice;
    public String date;

    // Default constructor (required for Firebase)
    public PaymentHistory() {}

    // Constructor with parameters
    public PaymentHistory(String username, String totalPrice, String date) {
        this.username = username;
        this.totalPrice = totalPrice;
        this.date = date;
    }
}

