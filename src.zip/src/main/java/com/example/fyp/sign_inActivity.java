package com.example.fyp;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.health.connect.datatypes.units.Length;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fyp.R;
import com.example.fyp.sign_upActivity;
import com.example.fyp.user_IntActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import android.speech.tts.TextToSpeech;

import java.util.Locale;
import java.util.Objects;

public class sign_inActivity extends AppCompatActivity {

    EditText emailEditText, passwordEditText;
    Button signInButton, signUpButton;
    FirebaseAuth mAuth;
    TextView forgotPassword, adminEditText;
    private TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_in);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance(); // Initialize FirebaseAuth instance

        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        signInButton = findViewById(R.id.sign_in_button);
        signUpButton = findViewById(R.id.sign_up_button);
        forgotPassword = findViewById(R.id.forgot_password_button);
        adminEditText = findViewById(R.id.admin);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    // Set language for TTS
                    int result = textToSpeech.setLanguage(Locale.ENGLISH);
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(sign_inActivity.this, "Language not supported for TTS", Toast.LENGTH_SHORT).show();
                    } else {
                        // Speak the text once TTS is ready
                        speakInstructions();
                    }
                } else {
                    Toast.makeText(sign_inActivity.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }

            private void speakInstructions() {
                String instructions = "Enter email address and password to sign in. Click the orange button to sign in and blue button for signup.";
                textToSpeech.speak(instructions, TextToSpeech.QUEUE_FLUSH, null, null); // Speak the text
            }
        });
 
        // Set onClickListeners for email and password EditTexts
        emailEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakText("Enter email address");
            }
        });

        passwordEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakText("Enter password");
            }
        });

        // Set input type programmatically for password masking
        passwordEditText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        adminEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(sign_inActivity.this, adminSignIn.class);
                startActivity(myIntent);
            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (!validateEmail() || !validatePassword()) {
                    return;
                }

                signInUser(email, password); // Call sign-in function
            }
        });

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(sign_inActivity.this, sign_upActivity.class);
                speakText("sign up button");
                startActivity(myIntent);
            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(sign_inActivity.this);
                View dialogView = getLayoutInflater().inflate(R.layout.dialog_forgot, null);
                EditText emailBox = dialogView.findViewById(R.id.emailBox);

                builder.setView(dialogView);
                AlertDialog dialog = builder.create();

                dialogView.findViewById(R.id.btnReset).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String userEmail = emailBox.getText().toString();

                        if (TextUtils.isEmpty(userEmail) && !Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()){
                            Toast.makeText(sign_inActivity.this, "Enter Your Registered Email Address", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        mAuth.sendPasswordResetEmail(userEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(sign_inActivity.this, "Check Your Email", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                } else {
                                    Toast.makeText(sign_inActivity.this, "Unable To Send, Failed", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
                    }
                });
                dialogView.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                }
                dialog.show();
            }
        });

    }

    // Helper method to speak text
    private void speakText(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }



    public Boolean validateEmail() {
        String email = emailEditText.getText().toString().trim();
        if (email.isEmpty()) {
            emailEditText.setError("Email cannot be empty");
            speakText("enter email");
            return false;
        } else {
            emailEditText.setError(null);
            return true;
        }
    }

    public Boolean validatePassword() {
        String password = passwordEditText.getText().toString().trim();
        if (password.isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            speakText("enter password");
            return false;
        } else {
            passwordEditText.setError(null);
            return true;
        }
    }

    private void signInUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Sign-in successful
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            Toast.makeText(sign_inActivity.this, "Sign-in successful!", Toast.LENGTH_SHORT).show();
                            speakText("Sign in successfully");

                            // Retrieve username from the database
                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
                            String userId = user.getUid(); // Authenticated user's unique ID
                            reference.child(userId).get().addOnCompleteListener(dbTask -> {
                                if (dbTask.isSuccessful() && dbTask.getResult().exists()) {
                                    String username = dbTask.getResult().child("username").getValue(String.class);

                                    // Navigate to user_IntActivity with the username
                                    Intent intent = new Intent(sign_inActivity.this, user_IntActivity.class);
                                    intent.putExtra("username", username != null ? username : "User");
                                    startActivity(intent);
                                    finish(); // Close sign-in activity
                                } else {
                                    Toast.makeText(sign_inActivity.this, "Error retrieving user data.", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } else {
                        // Sign-in failed
                        Toast.makeText(sign_inActivity.this, "Authentication failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        speakText("Authentication failed please check your email address and password");
                    }
                });
    }
}