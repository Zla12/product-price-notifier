package com.example.fyp;

public class User {

    // Fields
    private String username; // For Firebase data mapping
    private String email; // For Firebase data mapping
    private String phoneNumber; // For Firebase data mapping
    private boolean isSelected; // For RecyclerView selection
    private int no; // For numbering in your RecyclerView

    // Constructor for RecyclerView data
    public User(int no, String username, String phoneNumber, String email, boolean isSelected) {
        this.no = no;
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.isSelected = isSelected;
    }

    // Empty constructor (Required for Firebase Realtime Database)
    public User() {}

    // Constructor for Firebase mapping
    public User(String username, String email, String phoneNumber) {
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }
}
