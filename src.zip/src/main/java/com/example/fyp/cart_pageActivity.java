package com.example.fyp;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.speech.tts.TextToSpeech;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class cart_pageActivity extends AppCompatActivity {

    private TextView productName, productPrice, productExpDate, quantityText;
    private ImageView productImage;
    private String scannedBarcode, productImageUrl;
    private int quantity = 1;
    private boolean isMalay = false;
    private TextToSpeech textToSpeech;
    private String originalName;
    private String originalPriceStr;
    private String originalExpiryDate;
    private boolean isFirstCancelClick = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_page);

        // Initialize UI components
        productName = findViewById(R.id.product_name);
        productPrice = findViewById(R.id.product_price);
        productExpDate = findViewById(R.id.product_exp_date);
        quantityText = findViewById(R.id.quantity_text);
        productImage = findViewById(R.id.product_image);
        ImageView cartIcon = findViewById(R.id.cartIcon);
        ImageButton voiceNameButton = findViewById(R.id.voice_name);
        ImageButton voicePriceButton = findViewById(R.id.voice_price);
        ImageButton voiceExpDateButton = findViewById(R.id.voice_exp_date);
        Switch toggleButton = findViewById(R.id.language_toggle);

        // Set up listeners for TTS buttons
        voiceNameButton.setOnClickListener(v -> speakText(productName.getText().toString()));
        voicePriceButton.setOnClickListener(v -> {
            String spokenPrice = convertPriceToWords(productPrice.getText().toString(), isMalay);
            speakText(spokenPrice);
        });
        voiceExpDateButton.setOnClickListener(v -> {
            String expDate = productExpDate.getText().toString();

            // Determine the spoken phrase based on the selected language
            String spokenText;
            if (isMalay) {
                spokenText = "Tamat tempoh pada " + expDate; // Malay
            } else {
                spokenText = "Expired on " + expDate; // English
            }

            // Speak the expiry date
            speakText(spokenText);
        });

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(Locale.ENGLISH);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(this, "TTS Language not supported!", Toast.LENGTH_SHORT).show();
                } else {
                    if (scannedBarcode != null) {
                        fetchProductDetails(scannedBarcode); // Start fetching details after TTS initialization
                    }
                }
            } else {
                Toast.makeText(this, "TTS Initialization failed!", Toast.LENGTH_SHORT).show();
            }
        });

        // Language toggle button listener
        toggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isMalay = isChecked;
            updateLanguageDisplay();

            // Speak the language name when toggled
            String language = isMalay ? "Bahasa Melayu" : "English";
            speakText(language);

            if (isMalay) {
                setTTSLanguage(new Locale("ms", "MY")); // Malay
                Toast.makeText(this, "Language set to Malay", Toast.LENGTH_SHORT).show();
            } else {
                setTTSLanguage(Locale.ENGLISH); // English
                Toast.makeText(this, "Language set to English", Toast.LENGTH_SHORT).show();
            }
        });

        // Cart Button
        cartIcon.setOnClickListener(new ClickWithSpeechListener(this, "Shopping cart button", v -> {
            Intent myIntent = new Intent(cart_pageActivity.this, shoppingCart_pageActivity.class);
            startActivity(myIntent);
        }));

        // Retrieve the barcode from the Intent
        scannedBarcode = getIntent().getStringExtra("BARCODE");
        if (scannedBarcode != null) {
            // Fetch product details from Firebase based on the barcode
            fetchProductDetails(scannedBarcode);
        } else {
            Toast.makeText(this, "No barcode scanned", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity if no barcode is present
        }

        // Set up quantity buttons
        Button increaseButton = findViewById(R.id.quantity_increase);
        Button decreaseButton = findViewById(R.id.quantity_decrease);
        // Handle quantity increase with speech on first click
        increaseButton.setOnClickListener(new ClickWithSpeechListener(this, "Increase item button", v -> {
            // Second click functionality: Increase quantity
            updateQuantity(++quantity);
        }));

        // Handle quantity decrease with speech on first click
        decreaseButton.setOnClickListener(new ClickWithSpeechListener(this, "Decrease item button", v -> {
            // Second click functionality: Decrease quantity
            if (quantity > 1) updateQuantity(--quantity);
        }));

        Button cancelButton = findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(view -> {
            if (isFirstCancelClick) {
                // First click: Speak "Cancel button"
                speakText("Cancel button");
                isFirstCancelClick = false; // Update the flag
            } else {
                // Second click: Navigate back to user_IntActivity without speaking
                Intent myIntent = new Intent(cart_pageActivity.this, user_IntActivity.class);
                myIntent.putExtra("skipSpeech", true);
                startActivity(myIntent);
                finish(); // Close cart_pageActivity
            }
        });

        // Add to Cart button functionality
        Button addToCartButton = findViewById(R.id.add_to_cart_button);
        // Handle add to cart button with speech on first click
        addToCartButton.setOnClickListener(new ClickWithSpeechListener(this, "Add to cart button", v -> {
            String name = productName.getText().toString();
            String priceString = productPrice.getText().toString().replace("RM", "").trim();
            String barcode = scannedBarcode; // Barcode as the unique identifier

            try {
                double price = Double.parseDouble(priceString); // Parse price as double

                if (!name.isEmpty() && price > 0) {
                    // Add item to the cart
                    CartManager.getInstance().addItem(barcode, name, price, quantity, productImageUrl);

                    // Update the quantity in Firebase
                    DatabaseReference productRef = FirebaseDatabase.getInstance().getReference("barcodes").child(barcode);

                    productRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                Product product = dataSnapshot.getValue(Product.class);

                                if (product != null) {
                                    // Deduct quantity
                                    int currentQuantity = Integer.parseInt(product.getQuantity());
                                    int newQuantity = currentQuantity - quantity; // Subtract the quantity being added to cart

                                    if (newQuantity < 0) {
                                        Toast.makeText(cart_pageActivity.this, "Insufficient stock!", Toast.LENGTH_SHORT).show();
                                        return;
                                    }

                                    // Update quantity in Firebase
                                    productRef.child("quantity").setValue(String.valueOf(newQuantity))
                                            .addOnSuccessListener(aVoid -> {
                                                Toast.makeText(cart_pageActivity.this, "Item added to cart!", Toast.LENGTH_SHORT).show();
                                                // Speak "Item added to cart"
                                                if (textToSpeech != null) {
                                                    textToSpeech.speak("Item added to cart", TextToSpeech.QUEUE_FLUSH, null, "itemAddedUtterance");
                                                    textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                                                        @Override
                                                        public void onStart(String utteranceId) {
                                                            // No action needed when speech starts
                                                        }

                                                        @Override
                                                        public void onDone(String utteranceId) {
                                                            if ("itemAddedUtterance".equals(utteranceId)) {
                                                                // Navigate to shopping cart page after speech finishes
                                                                Intent intent = new Intent(cart_pageActivity.this, shoppingCart_pageActivity.class);
                                                                startActivity(intent);
                                                                finish();
                                                            }
                                                        }

                                                        @Override
                                                        public void onError(String utteranceId) {
                                                            Log.e("TTS", "Error occurred during speech: " + utteranceId);
                                                        }
                                                    });
                                                }
                                            })
                                            .addOnFailureListener(e -> {
                                                Toast.makeText(cart_pageActivity.this, "Failed to update quantity", Toast.LENGTH_SHORT).show();
                                            });
                                }
                            } else {
                                Toast.makeText(cart_pageActivity.this, "Product not found in database", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(cart_pageActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(this, "Invalid product details", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Price format is invalid!", Toast.LENGTH_SHORT).show();
            }
        }));

    }

    private void updateLanguageDisplay() {
        // Update the name and price (remains the same in both languages)
        productName.setText(originalName);
        productPrice.setText("RM " + originalPriceStr);

        // Update the expiry date based on the language
        if (isMalay) {
            productExpDate.setText(" " + originalExpiryDate);
        } else {
            productExpDate.setText(" " + originalExpiryDate);
        }
    }

    private void setTTSLanguage(Locale locale) {
        int result = textToSpeech.setLanguage(locale);
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Selected language is not supported!", Toast.LENGTH_SHORT).show();
        }
    }

    private String convertPriceToWords(String price, boolean isMalay) {
        try {
            // Remove "RM" and trim whitespace for parsing
            double amount = Double.parseDouble(price.replace("RM", "").trim());
            int ringgit = (int) amount;
            int cents = (int) Math.round((amount - ringgit) * 100);

            // Build spoken price string
            StringBuilder spokenPrice = new StringBuilder();
            if (ringgit > 0) {
                if (isMalay) {
                    spokenPrice.append(numberToMalay(ringgit)).append(" ringgit");
                } else {
                    spokenPrice.append(ringgit).append(" ringgit");
                }
            }
            if (cents > 0) {
                if (ringgit > 0) spokenPrice.append(isMalay ? " dan " : " and ");
                if (isMalay) {
                    spokenPrice.append(numberToMalay(cents)).append(" sen");
                } else {
                    spokenPrice.append(cents).append(" cent");
                }
            }
            return spokenPrice.toString();
        } catch (Exception e) {
            return isMalay ? "Format harga tidak sah" : "Invalid price format";
        }
    }

    private String numberToMalay(int number) {
        // Malay words for numbers
        String[] malayNumbers = {
                "kosong", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "lapan", "sembilan",
                "sepuluh", "sebelas", "dua belas", "tiga belas", "empat belas", "lima belas", "enam belas",
                "tujuh belas", "lapan belas", "sembilan belas"
        };

        String[] tens = {
                "", "", "dua puluh", "tiga puluh", "empat puluh", "lima puluh",
                "enam puluh", "tujuh puluh", "lapan puluh", "sembilan puluh"
        };

        if (number < 0) {
            return "Nombor tidak sah"; // Handle negative numbers
        }

        if (number < 20) {
            return malayNumbers[number];
        }

        int tenPart = number / 10;
        int unitPart = number % 10;

        if (tenPart >= tens.length) {
            return "Nombor terlalu besar"; // Handle numbers beyond supported range
        }

        if (unitPart == 0) {
            return tens[tenPart];
        }

        return tens[tenPart] + " " + malayNumbers[unitPart];

    }


    void speakText(String string) {
        if (textToSpeech != null) {
            textToSpeech.stop(); // Stop any ongoing speech
            if (!string.trim().isEmpty()) {
                textToSpeech.speak(string, TextToSpeech.QUEUE_FLUSH, null, null);
            } else {
                Toast.makeText(this, "No text to speak!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private void fetchProductDetails(String barcode) {
        DatabaseReference productRef = FirebaseDatabase.getInstance().getReference("barcodes").child(barcode);

        productRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    originalName = dataSnapshot.child("name").getValue(String.class);
                    originalPriceStr = dataSnapshot.child("price").getValue(String.class);
                    originalExpiryDate = dataSnapshot.child("expiryDate").getValue(String.class);
                    String imageUrl = dataSnapshot.child("image").getValue(String.class);

                    if (originalName == null || originalPriceStr == null || originalExpiryDate == null) {
                        Toast.makeText(cart_pageActivity.this, "Incomplete product details fetched.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    productName.setText(originalName);
                    productPrice.setText(String.format("RM %.2f", Double.parseDouble(originalPriceStr)));
                    productExpDate.setText(originalExpiryDate);

                    updateLanguageDisplay();

                    productImageUrl = convertGoogleDriveToDirectLink(imageUrl);
                    Glide.with(cart_pageActivity.this)
                            .load(productImageUrl)
                            .placeholder(new ColorDrawable(Color.GRAY))
                            .error(new ColorDrawable(Color.RED))
                            .into(productImage);

                    speakSequentially(originalName, convertPriceToWords(originalPriceStr, isMalay), originalExpiryDate);
                } else {
                    Toast.makeText(cart_pageActivity.this, "Product not found in database.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(cart_pageActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }

    private void speakSequentially(String name, String price, String expiryDate) {
        if (textToSpeech == null) return;

        if (name == null || price == null || expiryDate == null) {
            Toast.makeText(this, "Incomplete product details for TTS", Toast.LENGTH_SHORT).show();
            return;
        }

        textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {}

            @Override
            public void onDone(String utteranceId) {
                if ("speakName".equals(utteranceId)) {
                    textToSpeech.speak("Price: " + price, TextToSpeech.QUEUE_FLUSH, null, "speakPrice");
                } else if ("speakPrice".equals(utteranceId)) {
                    textToSpeech.speak("Expiry Date: " + expiryDate, TextToSpeech.QUEUE_FLUSH, null, "speakExpiryDate");
                }
            }

            @Override
            public void onError(String utteranceId) {
                Log.e("TTS", "Error occurred in utterance: " + utteranceId);
            }
        });

        textToSpeech.speak("Name: " + name, TextToSpeech.QUEUE_FLUSH, null, "speakName");
    }

    private String convertGoogleDriveToDirectLink(String driveLink) {
        if (driveLink.contains("drive.google.com")) {
            // Extract the file ID from the Google Drive link
            String[] parts = driveLink.split("/d/|/view");
            if (parts.length > 1) {
                String fileId = parts[1];
                // Return the direct download link
                return "https://drive.google.com/uc?id=" + fileId;
            }
        }
        return driveLink; // Return the original link if it's not a Google Drive link
    }

    private void updateQuantity(int newQuantity) {
        if (newQuantity > 0) { // Ensure quantity is non-negative
            quantity = newQuantity;
        }
        quantityText.setText(String.valueOf(quantity));

        // Speak the updated quantity
        if (textToSpeech != null) {
            String spokenQuantity = isMalay
                    ? "Kuantiti sekarang adalah " + numberToMalay(quantity)
                    : "Current quantity is " + quantity;
            textToSpeech.speak(spokenQuantity, TextToSpeech.QUEUE_FLUSH, null, "quantityUpdate");
        }
    }
}
