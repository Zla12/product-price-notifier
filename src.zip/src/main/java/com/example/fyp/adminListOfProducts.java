package com.example.fyp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class adminListOfProducts extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_list_of_products);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tableLayout = findViewById(R.id.tableLayout);

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("barcodes");

        // Fetch data and populate the table
        fetchProductData();

        // Set up button listeners
        Button btnDelete = findViewById(R.id.btn_delete);

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteSelectedRows();
            }
        });

        Button btnEdit = findViewById(R.id.btn_edit);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editSelectedRows();
            }
        });

        Button btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddDialog();
            }
        });

    }

    private void openAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Product");

        // Inflate the dialog view
        View dialogView = LayoutInflater.from(this).inflate(R.layout.add_product_dialog, null);
        builder.setView(dialogView);

        // Bind EditText fields to dialog elements
        EditText etBarcode = dialogView.findViewById(R.id.et_Barcode);
        EditText etName = dialogView.findViewById(R.id.et_name);
        EditText etPrice = dialogView.findViewById(R.id.et_price);
        EditText etExpDate = dialogView.findViewById(R.id.et_expDate);
        EditText etQuantity = dialogView.findViewById(R.id.et_quantity);
        EditText etImage = dialogView.findViewById(R.id.et_upload); // For the image link

        builder.setPositiveButton("Save", null); // Set to null to handle validation manually

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        saveButton.setOnClickListener(v -> {
            // Get input values
            String barcode = etBarcode.getText().toString().trim();
            String name = etName.getText().toString().trim();
            String price = etPrice.getText().toString().trim();
            String expiryDate = etExpDate.getText().toString().trim();
            String quantity = etQuantity.getText().toString().trim();
            String image = etImage.getText().toString().trim();

            // Validate input
            if (barcode.isEmpty() || name.isEmpty() || price.isEmpty() ||
                    expiryDate.isEmpty() || quantity.isEmpty() || image.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the barcode already exists in the database
            databaseReference.child(barcode).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Toast.makeText(getApplicationContext(), "Product with this barcode already exists.", Toast.LENGTH_SHORT).show();
                    } else {
                        // Create a product object
                        Product product = new Product(barcode, name, price, expiryDate, quantity, image);

                        // Save the product to the database
                        databaseReference.child(barcode).setValue(product).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "Product added successfully", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            } else {
                                Toast.makeText(getApplicationContext(), "Failed to add product", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getApplicationContext(), "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }


    private void fetchProductData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // Clear existing rows (except header)

                int index = 1;
                for (DataSnapshot productSnapshot : dataSnapshot.getChildren()) {
                    Product product = productSnapshot.getValue(Product.class);

                    if (product != null) {
                        addTableRow(productSnapshot.getKey(), String.valueOf(index), product.getBarcode(),
                                product.getName(), product.getPrice(), product.getExpiryDate(), product.getQuantity());
                        index++;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Error fetching data: " + databaseError.getMessage());
            }
        });

    }
    private void addTableRow(String key, String number, String barcode, String name, String price, String expiryDate, String quantity) {
        TableRow tableRow = new TableRow(this);
        tableRow.setTag(key); // Store the Firebase key in the row tag

        tableRow.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
        ));

        // Add CheckBox
        CheckBox checkBox = new CheckBox(this);
        tableRow.addView(checkBox);

        // Add columns with fixed widths
        tableRow.addView(createTextView(number, 50));    // Column 1: Number
        tableRow.addView(createTextView(barcode, 100));  // Column 2: Barcode
        tableRow.addView(createTextView(name, 150));     // Column 3: Name
        tableRow.addView(createTextView(price, 100));    // Column 4: Price
        tableRow.addView(createTextView(expiryDate, 150)); // Column 5: Expiry Date
        tableRow.addView(createTextView(quantity, 100)); // Column 6: Quantity

        tableLayout.addView(tableRow);

    }
    private void editSelectedRows() {
        for (int i = 1; i < tableLayout.getChildCount(); i++) { // Skip the header row
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            CheckBox checkBox = (CheckBox) row.getChildAt(0); // Get the checkbox

            if (checkBox.isChecked()) {
                // Retrieve data from the selected row
                String key = (String) row.getTag(); // Get the Firebase key from the tag
                TextView numberView = (TextView) row.getChildAt(1);
                TextView barcodeView = (TextView) row.getChildAt(2);
                TextView nameView = (TextView) row.getChildAt(3);
                TextView priceView = (TextView) row.getChildAt(4);
                TextView expiryDateView = (TextView) row.getChildAt(5);
                TextView quantityView = (TextView) row.getChildAt(6);

                String number = numberView.getText().toString();
                String barcode = barcodeView.getText().toString();
                String name = nameView.getText().toString();
                String price = priceView.getText().toString();
                String expiryDate = expiryDateView.getText().toString();
                String quantity = quantityView.getText().toString();

                // Open a dialog to edit this data
                openEditDialog(row, key, number, barcode, name, price, expiryDate, quantity);
                return;
            }
        }
    }

    private void openEditDialog(TableRow row, String key, String number, String barcode, String name, String price, String expiryDate, String quantity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Product");

        // Inflate the dialog view
        View dialogView = LayoutInflater.from(this).inflate(R.layout.edit_product_dialog, null);
        builder.setView(dialogView);

        // Bind EditText fields to dialog elements
        EditText etNumber = dialogView.findViewById(R.id.et_number);
        EditText etBarcode = dialogView.findViewById(R.id.et_Barcode);
        EditText etName = dialogView.findViewById(R.id.et_name);
        EditText etPrice = dialogView.findViewById(R.id.et_price);
        EditText etExpDate = dialogView.findViewById(R.id.et_expDate);
        EditText etQuantity = dialogView.findViewById(R.id.et_quantity);

        // Populate fields with current values
        etNumber.setText(number);
        etBarcode.setText(barcode);
        etName.setText(name);
        etPrice.setText(price);
        etExpDate.setText(expiryDate);
        etQuantity.setText(quantity);

        builder.setPositiveButton("Save", (dialog, which) -> {
            // Get updated values from EditText fields
            String updatedNumber = etNumber.getText().toString();
            String updatedBarcode = etBarcode.getText().toString();
            String updatedName = etName.getText().toString();
            String updatedPrice = etPrice.getText().toString();
            String updatedExpDate = etExpDate.getText().toString();
            String updatedQuantity = etQuantity.getText().toString();

            // Validation for empty fields
            if (updatedNumber.isEmpty() || updatedBarcode.isEmpty() || updatedName.isEmpty() ||
                    updatedPrice.isEmpty() || updatedExpDate.isEmpty() || updatedQuantity.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return; // Do not proceed with saving
            }

            // Update the TableRow's TextViews with new values
            ((TextView) row.getChildAt(1)).setText(updatedNumber);
            ((TextView) row.getChildAt(2)).setText(updatedBarcode);
            ((TextView) row.getChildAt(3)).setText(updatedName);
            ((TextView) row.getChildAt(4)).setText(updatedPrice);
            ((TextView) row.getChildAt(5)).setText(updatedExpDate);
            ((TextView) row.getChildAt(6)).setText(updatedQuantity);

            // Save updated values to the Firebase database
            saveUpdatedDataToDatabase(key, updatedBarcode, updatedName, updatedPrice, updatedExpDate, updatedQuantity);
            Toast.makeText(this, "Product updated successfully", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void saveUpdatedDataToDatabase(String key, String barcode, String name, String price, String expiryDate, String quantity) {
        DatabaseReference productRef = databaseReference.child(key); // Use the key for the specific product
        productRef.child("barcode").setValue(barcode);
        productRef.child("name").setValue(name);
        productRef.child("price").setValue(price);
        productRef.child("expiryDate").setValue(expiryDate);
        productRef.child("quantity").setValue(quantity);
    }


    private void deleteSelectedRows() {
        for (int i = 1; i < tableLayout.getChildCount(); i++) { // Skip the header row
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            CheckBox checkBox = (CheckBox) row.getChildAt(0);

            if (checkBox.isChecked()) {
                String key = (String) row.getTag(); // Get stored key
                databaseReference.child(key).removeValue().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d("DeleteSuccess", "Product deleted with key: " + key);
                    } else {
                        Log.e("DeleteError", "Failed to delete product with key: " + key);
                    }
                });

                tableLayout.removeView(row);
                i--; // Adjust index since rows shift after removal
            }

        }
    }


    private TextView createTextView(String text, int widthDp) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER); // Center alignment
        textView.setPadding(8, 8, 8, 8);     // Consistent padding

        // Convert DP to pixels
        int widthPx = (int) (widthDp * getResources().getDisplayMetrics().density);
        textView.setWidth(widthPx);

        // Apply border
        textView.setBackgroundResource(R.drawable.border);

        return textView;
    }
}


