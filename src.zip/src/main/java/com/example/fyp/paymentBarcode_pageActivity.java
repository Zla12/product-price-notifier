package com.example.fyp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.Locale;

public class paymentBarcode_pageActivity extends AppCompatActivity {

    private ImageView qrCodeImage;
    private ImageView barcodeImage;
    private ImageView logoutButton;
    private TextToSpeech textToSpeech;
    private boolean isFirstLogoutClick = true; // Flag to track the first click on logout button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_barcode_page);

        // Increase screen brightness for this page
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = 1.0f; // Maximum brightness (1.0f = 100%)
        getWindow().setAttributes(layoutParams);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(Locale.ENGLISH);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TTS", "Language not supported!");
                }
            }
        });


        double totalPrice = getIntent().getDoubleExtra("TOTAL_PRICE", 0.0);

        TextView totalPriceTextView = findViewById(R.id.total_price_text_view);
        totalPriceTextView.setText(String.format("Total Price: RM %.2f", totalPrice));

        qrCodeImage = findViewById(R.id.qrCodeImage);
        barcodeImage = findViewById(R.id.barcodeImage);

        generateQrCode(String.format("RM %.2f", totalPrice));
        generateBarcode(String.format("RM %.2f", totalPrice));

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(Locale.ENGLISH);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TTS", "Language not supported!");
                } else {
                    speakMessage(totalPrice);
                }
            }
        });

        logoutButton = findViewById(R.id.profileIcon);
        logoutButton.setOnClickListener(view -> {
            if (isFirstLogoutClick) {
                // First click: Speak "Log out button"
                speakText("Log out button");
                isFirstLogoutClick = false; // Update the flag
            } else {
                // Second click: Perform logout
                logoutUser();
            }
        });


        savePaymentHistory(totalPrice);
    }

    private void speakText(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            Log.e("TTS", "Text-to-Speech not initialized.");
        }
    }

    private void savePaymentHistory(double totalPrice) {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid(); // Get the current user's UID
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId);
        DatabaseReference paymentHistoryRef = FirebaseDatabase.getInstance().getReference("PaymentHistory");

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String username = dataSnapshot.child("username").getValue(String.class); // Fetch the username
                if (username != null) { // Ensure the username exists
                    String paymentId = paymentHistoryRef.push().getKey(); // Generate a unique payment ID
                    PaymentHistory payment = new PaymentHistory(username, String.format("%.2f", totalPrice), getCurrentDate());
                    if (paymentId != null) {
                        paymentHistoryRef.child(paymentId).setValue(payment)
                                .addOnSuccessListener(aVoid -> {
                                    Log.d("SavePayment", "Payment history saved successfully.");
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("SavePayment", "Failed to save payment history: " + e.getMessage());
                                });
                    }
                } else {
                    Log.e("SavePayment", "Username is null for userId: " + userId);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("SavePayment", "Database error: " + databaseError.getMessage());
            }
        });
    }


    private String getCurrentDate() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new java.util.Date());
    }

    private void speakMessage(double totalPrice) {
        String message1 = "Please show this at cashier counter.";
        String message2 = "The total price is " + convertPriceToWords(totalPrice);

        textToSpeech.speak(message1, TextToSpeech.QUEUE_FLUSH, null, "message1");
        textToSpeech.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {}

            @Override
            public void onDone(String utteranceId) {
                if ("message1".equals(utteranceId)) {
                    textToSpeech.speak(message2, TextToSpeech.QUEUE_FLUSH, null, "message2");
                }
            }

            @Override
            public void onError(String utteranceId) {
                Log.e("TTS", "Error occurred while speaking: " + utteranceId);
            }
        });
    }

    private String convertPriceToWords(double price) {
        int ringgit = (int) price; // Get the whole number part (ringgit)
        int cents = (int) Math.round((price - ringgit) * 100); // Get the fractional part (cents)

        StringBuilder priceInWords = new StringBuilder();

        if (ringgit > 0) {
            priceInWords.append(numberToWords(ringgit)).append(" ringgit");
        }
        if (cents > 0) {
            if (ringgit > 0) {
                priceInWords.append(" and ");
            }
            priceInWords.append(numberToWords(cents)).append(" cent");
        }

        return priceInWords.toString();
    }

    private String numberToWords(int number) {
        String[] units = {
                "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
        };

        String[] tens = {
                "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"
        };

        if (number < 20) {
            return units[number];
        } else if (number < 100) {
            int unit = number % 10;
            return tens[number / 10] + (unit > 0 ? " " + units[unit] : "");
        } else if (number < 1000) {
            int hundred = number / 100;
            int remainder = number % 100;
            return units[hundred] + " hundred" + (remainder > 0 ? " " + numberToWords(remainder) : "");
        } else {
            return "number too large"; // Handle numbers greater than 999 for simplicity
        }
    }


    private void generateQrCode(String data) {
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(data, BarcodeFormat.QR_CODE, 300, 300);
            qrCodeImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private void generateBarcode(String data) {
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(data, BarcodeFormat.CODE_128, 600, 150);
            barcodeImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private void logoutUser() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        Intent intent = new Intent(paymentBarcode_pageActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        // Restore default brightness
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(layoutParams);

        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
