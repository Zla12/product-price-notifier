package com.example.fyp;

/**
 * Represents a product in the Firebase database.
 */
public class Product {
    private String barcode;     // Unique identifier (key in Firebase)
    private String name;        // Name of the product
    private String price;       // Price of the product
    private String expiryDate;  // Expiry date of the product
    private String quantity;    // Quantity available
    private String image;       // URL for the product image

    // Default constructor required for Firebase
    public Product() {
    }

    // Constructor to initialize fields
    public Product(String barcode, String name, String price, String expiryDate, String quantity, String image) {
        this.barcode = barcode;
        this.name = name;
        this.price = price;
        this.expiryDate = expiryDate;
        this.quantity = quantity;
        this.image = image;
    }

    // Getters and setters
    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Product{" +
                "barcode='" + barcode + '\'' +
                ", name='" + name + '\'' +
                ", price='" + price + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", quantity='" + quantity + '\'' +
                ", image='" + image + '\'' +
                '}';
    }
}
