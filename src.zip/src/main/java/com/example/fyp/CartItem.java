package com.example.fyp;

/**
 * Represents an item in the shopping cart.
 */
public class CartItem {
    private final String id;       // Unique identifier for the item
    private final String name;     // Name of the product
    private final double price;    // Price of the product as a double for calculations
    private int quantity;          // Quantity of the product in the cart
    private String imageUrl;       // URL for the product image

    // Constructor
    public CartItem(String id, String name, double price, int quantity, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
    }

    // Getter for item ID
    public String getId() {
        return id;
    }

    // Getter for item name
    public String getName() {
        return name;
    }

    // Getter for item price
    public double getPrice() {
        return price;
    }

    // Getter for item price as a formatted string
    public String getFormattedPrice() {
        return String.format("RM %.2f", price);
    }

    // Getter for item quantity
    public int getQuantity() {
        return quantity;
    }

    // Setter for item quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter for image URL
    public String getImageUrl() {
        return imageUrl;
    }

    // Setter for image URL (if needed)
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    // Increment the quantity of the item
    public void incrementQuantity(int amount) {
        this.quantity += amount;
    }

    // Decrement the quantity of the item
    public void decrementQuantity(int amount) {
        this.quantity = Math.max(0, this.quantity - amount); // Prevent negative quantity
    }

    @Override
    public String toString() {
        return "CartItem{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}