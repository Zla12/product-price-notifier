package com.example.fyp;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class adminListOfUsersActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_list_of_users);

        tableLayout = findViewById(R.id.tableLayout);

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("users");
        // Fetch data and populate the table
        fetchUserData();

        // Set up button listeners (only once)
        Button btnDelete = findViewById(R.id.btn_delete);
        btnDelete.setOnClickListener(v -> deleteSelectedRows());

        Button btnEdit = findViewById(R.id.btn_edit);
        btnEdit.setOnClickListener(v -> editSelectedRows());
    }


    private void fetchUserData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("FetchData", "Data fetched from Firebase");
                tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // Clear previous rows (except header)

                int index = 1;
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    String key = userSnapshot.getKey(); // Extract the unique Firebase key
                    String username = userSnapshot.child("username").getValue(String.class);
                    String email = userSnapshot.child("email").getValue(String.class);
                    String phone = userSnapshot.child("phoneNumber").getValue(String.class);

                    Log.d("UserData", "Key: " + key + ", Username: " + username);

                    // Add the row to the table, including the key
                    addTableRow(key, String.valueOf(index), username, email, phone);
                    index++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Error fetching data: " + databaseError.getMessage());
            }
        });
    }

    private void addTableRow(String key, String number, String username, String email, String phone) {
        TableRow tableRow = new TableRow(this);
        tableRow.setTag(key); // Store the Firebase key in the row tag

        tableRow.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
        ));

        // Add CheckBox
        CheckBox checkBox = new CheckBox(this);
        tableRow.addView(checkBox);

        // Add columns with fixed widths
        tableRow.addView(createTextView(number, 50));    // Column 1: 50dp
        tableRow.addView(createTextView(username, 100)); // Column 2: 100dp
        tableRow.addView(createTextView(email, 200));    // Column 3: 200dp
        tableRow.addView(createTextView(phone, 150));    // Column 4: 150dp

        tableLayout.addView(tableRow);
    }


    private void editSelectedRows() {
        boolean isChecked = false;

        for (int i = 1; i < tableLayout.getChildCount(); i++) { // Skip the header row
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            CheckBox checkBox = (CheckBox) row.getChildAt(0); // Get the checkbox

            if (checkBox.isChecked()) {
                isChecked = true;
                // Retrieve data from the selected row
                String key = (String) row.getTag(); // Get the Firebase key from the tag
                TextView numberView = (TextView) row.getChildAt(1);
                TextView usernameView = (TextView) row.getChildAt(2);
                TextView emailView = (TextView) row.getChildAt(3);
                TextView phoneView = (TextView) row.getChildAt(4);

                String number = numberView.getText().toString();
                String username = usernameView.getText().toString();
                String email = emailView.getText().toString();
                String phone = phoneView.getText().toString();

                // Open a dialog to edit this data
                openEditDialog(row, key, number, username, email, phone);
                return;
            }
        }
    }

    private void openEditDialog(TableRow row, String key, String number, String username, String email, String phone) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit User");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.edit_user_dialod, null);
        builder.setView(dialogView);

        EditText etNumber = dialogView.findViewById(R.id.et_number);
        EditText etUsername = dialogView.findViewById(R.id.et_username);
        EditText etEmail = dialogView.findViewById(R.id.et_email);
        EditText etPhone = dialogView.findViewById(R.id.et_phone);

        etNumber.setText(number);
        etUsername.setText(username);
        etEmail.setText(email);
        etPhone.setText(phone);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String updatedNumber = etNumber.getText().toString();
            String updatedUsername = etUsername.getText().toString();
            String updatedEmail = etEmail.getText().toString();
            String updatedPhone = etPhone.getText().toString();

            ((TextView) row.getChildAt(1)).setText(updatedNumber);
            ((TextView) row.getChildAt(2)).setText(updatedUsername);
            ((TextView) row.getChildAt(3)).setText(updatedEmail);
            ((TextView) row.getChildAt(4)).setText(updatedPhone);

            saveUpdatedDataToDatabase(key, updatedUsername, updatedEmail, updatedPhone);
            Toast.makeText(this, "User updated successfully", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void saveUpdatedDataToDatabase(String key, String username, String email, String phone) {
        DatabaseReference userRef = databaseReference.child(key); // Use the key for the specific user
        userRef.child("username").setValue(username);
        userRef.child("email").setValue(email);
        userRef.child("phoneNumber").setValue(phone);
    }

    private void deleteSelectedRows() {
        for (int i = 1; i < tableLayout.getChildCount(); i++) { // Skip the header row
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            CheckBox checkBox = (CheckBox) row.getChildAt(0);

            if (checkBox.isChecked()) {
                String key = (String) row.getTag(); // Get stored key
                databaseReference.child(key).removeValue().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d("DeleteSuccess", "User deleted with key: " + key);
                    } else {
                        Log.e("DeleteError", "Failed to delete user with key: " + key);
                    }
                });

                tableLayout.removeView(row);
                i--; // Adjust index since rows shift after removal
            }
        }
    }

    private TextView createTextView(String text, int widthDp) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER); // Center alignment
        textView.setPadding(8, 8, 8, 8);     // Consistent padding

        // Convert dp to pixels for consistent column width
        int widthPx = (int) (widthDp * getResources().getDisplayMetrics().density);
        textView.setWidth(widthPx);

        // Apply border
        textView.setBackgroundResource(R.drawable.border);
        return textView;
    }
}